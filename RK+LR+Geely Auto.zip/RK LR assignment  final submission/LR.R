#--------------------------------#
# installing necessary packages #
#--------------------------------#

install.packages("MASS")
install.packages("car")
install.packages("dplyr")
install.packages("tidyr")
install.packages("stringr")
install.packages("reshape2")
install.packages("ggplot2")

library("reshape2")
library("MASS")
library("car")
library("dplyr")
library("tidyr")
library(ggplot2)

#-----------------------#
# Loading given dataset#
#-----------------------#

setwd("D:\\PGDDS\\Course-III\\LR\\Assignment\\Problem")
car_data <- read.csv("CarPrice_Assignment.csv")
View(car_data)
str(car_data)

#-----------------------#
# data cleanup #
#-----------------------#

# Checking for the duplicate rows if any using car_id #
#-----------------------------------------------------#
sum(duplicated(car_data$car_ID))

# Checking & Removing NA values if any in car_id and car_name #
#-------------------------------------------------------------#
which(is.na(car_data$car_ID))
which(is.na(car_data$CarName))


boxplot(car_data)
boxplot(car_data$enginesize)
boxplot(car_data$peakrpm)


#--------------------------------------------------------#
# Extracting the company name from the carname variable #
#--------------------------------------------------------#
car_name = colsplit(car_data$CarName, " ", c("company_name","model"))
car_data1 <- cbind(car_data[,-3],car_name)
car_data1 <- car_data1[,-27]
View(car_data1)




str(car_data1)

#-----------------------------------------------------------------#
# converting the carname variable from character type into factor #
#-----------------------------------------------------------------#

car_data1$company_name <- as.factor(car_data1$company_name)


# converting factor variables with two levels into numeric variables #
#---------------------------------------------------------------------#
str(car_data1)
str(car_data1$fueltype)
summary(factor(car_data1$fueltype))
levels(car_data1$fueltype) <- c(0,1)
car_data1$fueltype
car_data1$fueltype <- as.numeric(levels(car_data1$fueltype))[car_data1$fueltype]
summary(car_data1$fueltype)
str(car_data1)

summary(factor(car_data1$aspiration))
levels(car_data1$aspiration) <- c(1,0)
car_data1$aspiration <- as.numeric(levels(car_data1$aspiration)) [car_data1$aspiration]
car_data1$aspiration
summary(car_data1$aspiration)

summary(factor(car_data1$doornumber))
levels(car_data1$doornumber)<-c(1,0)
car_data1$doornumber <- as.numeric(levels(car_data1$doornumber))[car_data1$doornumber]
car_data1$doornumber
summary(car_data1$doornumber)

summary(factor(car_data1$enginelocation))
levels(car_data1$enginelocation)<-c(1,0)
car_data1$enginelocation <-as.numeric(levels(car_data1$enginelocation))[car_data1$enginelocation]
summary(car_data1$enginelocation)

#-------------------------------------------------------------------------------#
# creating necessary dummy variables and binding them into the given dataframe #
#-------------------------------------------------------------------------------#
str(car_data1)

summary(car_data1$carbody)
dummy_1 <- data.frame(model.matrix(~carbody, data = car_data1))
dummy_1 <- dummy_1[,-1]
dummy_1
car_data1 <- cbind(car_data1[,-6],dummy_1)
View(car_data1)

str(car_data1)
summary(car_data1$drivewheel)
dummy_2 <- data.frame(model.matrix(~drivewheel, data = car_data1))
dummy_2 <- dummy_2[,-1]
dummy_2
car_data1 <- cbind(car_data1[,-6],dummy_2)

str(car_data1)
summary(car_data1$enginetype)
dummy_3 <- data.frame(model.matrix(~enginetype,data = car_data1))
dummy_3 <- dummy_3[,-1]
car_data1<- cbind(car_data1[,-12],dummy_3)


summary(car_data1$cylindernumber)
dummy_4 <- data.frame(model.matrix(~cylindernumber, data = car_data1))
dummy_4 <- dummy_4[,-1]
car_data1 <- cbind(car_data1[,-12],dummy_4)


summary(car_data1$fuelsystem)
dummy_5 <- data.frame(model.matrix(~fuelsystem, data = car_data1))
dummy_5 <- dummy_5[,-1]
str(car_data1)
car_data1 <- cbind(car_data1[,-13],dummy_5)

summary(car_data1$company_name)
dummy_6 <- data.frame(model.matrix(~company_name, data=car_data1))
dummy_6 <- dummy_6[,-1]
View(car_data1)
str(car_data1)
car_data1 <- cbind(car_data1[,-21],dummy_6)

View(car_data1)
str(car_data1)
#---------------------------#
# deriving new metrics #
#--------------------------#

car_data1$engine_aspect_ratio <- car_data1$boreratio/car_data1$stroke

car_data1$torque <- car_data1$horsepower*5252/car_data1$peakrpm




View(car_data1)
str(car_data1)
summary(car_data1)

car_data1 <- select(car_data1,-27,-38,-41,-42,-54,-60,-66,-68,-69,-72)
View(car_data1)



#---------------------------------------------#
# Separating Training Data from the data set #
#---------------------------------------------#

set.seed(nrow(car_data1))
train_indices <- sample(1:nrow(car_data1),0.7*nrow(car_data1))
train <- car_data1[train_indices,]

sum(is.na(train))

#--------------------------------------------#
# Separating Testing Data from the data set #
#--------------------------------------------#
test <- car_data1[-train_indices, ]

#-----------------#
# Model Building #
#-----------------#

model_1 <- lm(price~., data=train)
summary(model_1)
corrs = cor(car_data1)
vif(model_1)
vif(lm(price~., data=train))


# Model 2 #
#----------#
train <- train[,-1]

model_2 <- lm(price~., data=train)
summary(model_2)
vif(model_2)

# Model 3 #
#-----------#
train <- train[,-2]

model_3 <- lm(price~., data=train)
summary(model_3)
vif(model_3)

# Model 4 #
#-----------#
train <- train[,-6]
model_4 <- lm(price~., data=train)
summary(model_4)
vif(model_4)

# Model 5 #
#-----------#
train <- train[,-15]
model_5 <- lm(price~., data=train)
summary(model_5)
vif(model_5)

# Model 6 #
#-----------#
train <- train[,-5]
model_6 <- lm(price~., data=train)
summary(model_6)
vif(model_6)

# Model 7 #
#-----------#
train <- train[,-11]
model_7 <- lm(price~., data=train)
summary(model_7)
vif(model_7)

# Model 8 #
#-----------#
train <- train[,-12]
model_8 <- lm(price~., data=train)
summary(model_8)
vif(model_8)

# Model 9 #
#-----------#
train <- train[,-26]
model_9 <- lm(price~., data=train)
summary(model_9)
vif(model_9)

# Model 10 #
#-----------#
train <- train[,-9]
model_10 <- lm(price~., data=train)
summary(model_10)
vif(model_10)


# Model 11 #
#-----------#
train <- train[,-30]
model_11 <- lm(price~., data=train)
summary(model_11)
vif(model_11)

# Model 12 #
#-----------#
train <- train[,-21]
model_12 <- lm(price~., data=train)
summary(model_12)
vif(model_12)

# Model 13 #
#-----------#
train <- train[,-18]
model_13 <- lm(price~., data=train)
summary(model_13)
vif(model_13)

# Model 14 #
#-----------#
train <- train[,-6]
model_14 <- lm(price~., data=train)
summary(model_14)
vif(model_14)

# Model 15 #
#-----------#
train <- train[,-18]
model_15 <- lm(price~., data=train)
summary(model_15)
vif(model_15)

# Model 16 #
#-----------#
train <- train[,-16]
model_16 <- lm(price~., data=train)
summary(model_16)
vif(model_16)

# Model 17 #
#-----------#
train <- train[,-29]
model_17 <- lm(price~., data=train)
summary(model_17)
vif(model_17)


# Model 18 #
#-----------#
train <- train[,-17]
model_18 <- lm(price~., data=train)
summary(model_18)
vif(model_18)


# Model 19 #
#-----------#
train <- train[,-3]
model_19 <- lm(price~., data=train)
summary(model_19)
vif(model_19)

# Model 20 #
#-----------#
train <- train[,-1]
model_20 <- lm(price~., data=train)
summary(model_20)
vif(model_20)

# Model 21 #
#-----------#
train <- train[,-20]
model_21 <- lm(price~., data=train)
summary(model_21)
vif(model_21)

# Model 22 #
#-----------#
train <- train[,-20]
model_22 <- lm(price~., data=train)
summary(model_22)
vif(model_22)

# Model 23 #
#-----------#
train <- train[,-28]
model_23 <- lm(price~., data=train)
summary(model_23)
vif(model_23)

# Model 24 #
#-----------#
train <- train[,-34]
model_24 <- lm(price~., data=train)
summary(model_24)
vif(model_24)

# Model 25 #
#-----------#
train <- train[,-20]
model_25 <- lm(price~., data=train)
summary(model_25)
vif(model_25)

# Model 26 #
#-----------#
train <- train[,-16]
model_26 <- lm(price~., data=train)
summary(model_26)
vif(model_26)

# Model 27 #
#-----------#
train <- train[,-19]
model_27 <- lm(price~., data=train)
summary(model_27)
vif(model_27)

# Model 28 Volvo #
#-----------#
train <- train[,-36]
model_28 <- lm(price~., data=train)
summary(model_28)
vif(model_28)

# Model 29 Volvo #
#-----------#
train <- train[,-33]
model_29 <- lm(price~., data=train)
summary(model_29)
vif(model_29)


# Model 30 Volvo #
#-----------#
train <- train[,-26]
model_30 <- lm(price~., data=train)
summary(model_30)
vif(model_30)



# Model 31  #
#-----------#
train <- train[,-4]
model_31 <- lm(price~., data=train)
summary(model_31)
vif(model_31)


# Model 32  #
#-----------#
train <- train[,-7]
model_32 <- lm(price~., data=train)
summary(model_32)
vif(model_32)



# Model 33 #
#-----------#
train <- train[,-28]
model_33 <- lm(price~., data=train)
summary(model_33)
vif(model_33)

# Model 34 #
#-----------#
train <- train[,-22]
model_34 <- lm(price~., data=train)
summary(model_34)
vif(model_34)



# Model 35 #
#-----------#
train <- train[,-19]
model_35 <- lm(price~., data=train)
summary(model_35)
vif(model_35)


# Model 36 #
#-----------#
train <- train[,-21]
model_36 <- lm(price~., data=train)
summary(model_36)
vif(model_36)


# Model 37 #
#-----------#
train <- train[,-17]
model_37 <- lm(price~., data=train)
summary(model_37)
vif(model_37)


# Model 38 #
#-----------#
train <- train[,-23]
model_38 <- lm(price~., data=train)
summary(model_38)
vif(model_38)


# Model 39 #
#-----------#
train <- train[,-22]
model_39 <- lm(price~., data=train)
summary(model_39)
vif(model_39)

# Model 40 #
#-----------#
train <- train[,-23]
model_40 <- lm(price~., data=train)
summary(model_40)
vif(model_40)

# Model 41 #
#-----------#
train <- train[,-19]
model_41 <- lm(price~., data=train)
summary(model_41)
vif(model_41)


# Model 42 #
#-----------#
train <- train[,-11]
model_42 <- lm(price~., data=train)
summary(model_42)
vif(model_42)


# Model 43 #
#-----------#
train <- train[,-10]
model_43 <- lm(price~., data=train)
summary(model_43)
vif(model_43)


# Model 44 #
#-----------#
train <- train[,-9]
model_44 <- lm(price~., data=train)
summary(model_44)
vif(model_44)

# Model 45 #
#-----------#
train <- train[,-8]
model_45 <- lm(price~., data=train)
summary(model_45)
vif(model_45)


# Model 46 #
#-----------#
train <- train[,-14]
model_46 <- lm(price~., data=train)
summary(model_46)
vif(model_46)

# Model 47 #
#-----------#
train <- train[,-16]
model_47 <- lm(price~., data=train)
summary(model_47)
vif(model_47)

# Model 48 #
#-----------#
train <- train[,-16]
model_48 <- lm(price~., data=train)
summary(model_48)
vif(model_48)


# Model 49 #
#-----------#
train <- train[,-15]
model_49 <- lm(price~., data=train)
summary(model_49)
vif(model_49)


# Model 50 #
#-----------#
train <- train[,-6]
model_50 <- lm(price~., data=train)
summary(model_50)
vif(model_50)


# Model 51 #
#-----------#
train <- train[,-15]
model_51 <- lm(price~., data=train)
summary(model_51)
vif(model_51)


# Model 52 #
#-----------#
train <- train[,-7]
model_52 <- lm(price~., data=train)
summary(model_52)
vif(model_52)

# Model 53 #
#-----------#
train <- train[,-9]
model_53 <- lm(price~., data=train)
summary(model_53)
vif(model_53)


# Model 54 #
#-----------#
train <- train[,-11]
model_54 <- lm(price~., data=train)
summary(model_54)
vif(model_54)


#---------------------------------------------------------#
# Predicting with the developed model using test data set#
#---------------------------------------------------------#

predict_1 <- predict(model_54,test[,-1])
test$test_price <- predict_1

r <- cor(test$price,test$test_price)
rsquared <- cor(test$price,test$test_price)^2
rsquared
